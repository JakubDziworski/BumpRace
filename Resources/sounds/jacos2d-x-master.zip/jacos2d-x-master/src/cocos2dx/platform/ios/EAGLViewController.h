//
//  EAGLViewController.h
//  cocos2dx
//
//  Created by Thai Duong on 2/3/13.
//  Copyright (c) 2013 厦门雅基软件有限公司. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EAGLViewController : UIViewController

@end
